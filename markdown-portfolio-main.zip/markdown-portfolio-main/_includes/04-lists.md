1. Favourite books:
  * Marthians
  * Painted Veil
2. Favorite places to eat:
  * Tarelka
  * McDonalds
